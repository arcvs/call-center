<template>
  <div class="requests">

      <el-table
        cell-class-name="cell"
        :data="tableData"
        row-key="request_id"
        height="90%"
        :default-sort = "{prop: 'request_id', order: 'ascending'}">

        <el-table-column 
          type="expand" 
        >
          <template slot-scope="props">
            <div class="info_request">

              <div>
                <p><b>Номер для обратного вызова:</b> {{ props.row.number_callback }}</p>
                <p><b>Департамент принявший обращение:</b> {{ props.row.created_of_department_name }}</p>
                <p><b>Отдел принявший обращение:</b> {{ props.row.created_of_group_name }}</p>
                <p><b>Принято оператором:</b> {{ props.row.created_of_first_name }} {{ props.row.created_of_last_name }}</p>
                <p><b>Время создания обращения:</b> {{ formatedDate(props.row.date_start) }}</p>
                <p><b>Время завершения обработки обращения:</b> {{ formatedDate(props.row.date_end) }}</p>
                <br>
                <p><b>Описание:</b> {{ props.row.description_request }}</p>
                <br><br><br>
                <el-button
                  size="mini"
                  type="danger"
                  plain
                  @click="SetStatusRequest(props.row.request_id, 0)">Удалить обращение</el-button>
              </div>
              <div>
                <el-button plain size="mini" type="primary" v-on:click="CreateNoteToRequest(props.row.request_id, props.row.note_to_request)">Сохранить примечание</el-button>
                <el-input
                  class="marginTextArea"
                  type="textarea"
                  :autosize="{minRows: 5}"
                  placeholder="Детализация обращение"
                  v-model="props.row.note_to_request">
                </el-input>
              </div>

            </div>

          </template>
        </el-table-column>

        <el-table-column
          width="150px"
          prop="request_id"
          label="№ обращения"
          sortable>
        </el-table-column>

        <el-table-column
          width="190px"
          label="Время обращения">
          <template slot-scope="scope">
            <p style="font-size: 9pt">{{ scope.row.date_format }}</p>
            <p style="font-style: italic; font-size: 8pt; color: #999"><i class="el-icon-time"></i> {{ scope.row.date_formatNow }}</p>
          </template>
        </el-table-column>

        <el-table-column
          prop="topic_request"
          label="Тема">
        </el-table-column>

        <el-table-column
          width="150px"
          prop="first_name_consumer"
          label="Имя абонента">
        </el-table-column>

        <el-table-column
          width="140px"
          prop="number_callback"
          label="Номер телефона">
        </el-table-column>

        <el-table-column
          width="120px"
          prop="email_consumer"
          label="Email">
        </el-table-column>

        <el-table-column
          prop="name_department"
          label="Отдел/Департамент">
          <template slot-scope="scope">
            <p style="font-size: 9pt">{{ scope.row.name_group }}</p>
            <p style="font-style: italic; font-size: 8pt; color: #999">{{ scope.row.name_department }}</p>
          </template>
        </el-table-column>

        <el-table-column
          width="160px"
          prop="text_status"
          label="Статус">
            <template slot-scope="scope">
              <el-popover trigger="hover" placement="top">
                <p v-show="scope.row.status_request != 1">Диспетчер: {{ scope.row.processed_of_first_name }} {{ scope.row.processed_of_last_name }}</p>
                <p v-show="scope.row.status_request != 1">Время: {{ scope.row.date_processed_format }}</p>
                <div slot="reference" class="name-wrapper">

                  <el-tag size="small"
                    :type="scope.row.status_request != 1 ? (scope.row.status_request == 2 ? 'warning': 'success') : 'danger'">
                    {{ scope.row.text_status }}
                  </el-tag>

                </div>
              </el-popover>
            </template>
        </el-table-column>

        <el-table-column
          width="250px"
          label="Операции">
            <template slot-scope="scope">
              <el-button
                v-show="scope.row.status_request == 1"
                size="mini"
                type="primary"
                @click="SetStatusRequest(scope.row.request_id, 2)">Принять</el-button>
              <el-button
                v-show="scope.row.status_request == 2"
                size="mini"
                type="success"
                @click="SetStatusRequest(scope.row.request_id, 3)">Завершить</el-button>
              <el-button
                v-show="scope.row.status_request == 2"
                size="mini"
                type="danger"
                plain
                @click="SetStatusRequest(scope.row.request_id, 1)">В очередь</el-button>
          </template>
        </el-table-column>

      </el-table>

  </div>
</template>


<script>

  import moment from 'moment'

  export default {

    components: {
    },

    computed: {
      tableData: function () {
        return this.$store.state.requests
      }
    },

    data() { //this.$store.state.requests
      return {
        noteToRequest: ''
      }
    },

    mounted() {
      //console.log(moment('2018-12-27T03:01:44.876Z').format('Do MMMM YYYY, h:mm:ss a'))
    },

    methods: {
      formatedDate(date){
        if (date != null) {
          return moment(date).format('D-MM-YYYY / HH:mm:ss')
        }
      },
      SetStatusRequest(request_id, status_request){
        this.$store.commit('SetStatusRequest', {request_id: request_id, status_request: status_request})
      },
      CreateNoteToRequest(request_id, note_to_request){
        this.$store.commit('CreateNoteToRequest', {request_id: request_id, note_to_request: note_to_request})
      },

      formatter(row, column) {
        return row.address;
      },
      increment () {
        
        //this.tableData = this.$store.state.requests
        //console.log(this.$store.state.requests)
      },
      decrement () {
        //this.$store.commit('decrement')
      }
    }
  }

</script>


<style lang="scss">
  .requests {
    height: 100%;
    padding-top: 54px;
    width: 100%;
    position: fixed;
  }
  .requests .cell {
    word-break: keep-all;
  }
  .requests .info_request {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: stretch;
  }
  .requests .info_request p {
    padding-bottom: 7px;
  }
  .requests .info_request .marginTextArea {
    width: 100%;
    margin: 30px;
    margin-top: 20px;
    margin-left: 0px;
  }
  .requests .cell p {
    line-height: 14pt;
  }
  .requests .cell .el-button {
    margin-left: 0;
    margin-right: 10px;
  }
</style>
