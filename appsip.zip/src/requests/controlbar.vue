<template>
  <div class="controlbar">

    <div class="account">
      <p class="account__first_name">
        {{account.first_name}} {{account.last_name}}
      </p>
    </div>
    <div>
      <el-button size="mini" type="warning" plain @click="GetListRequsetProcessed()">Обращения в очереди и обработке</el-button>
      <el-button size="mini" type="success" plain @click="GetListRequsetClosed()">Завершенные обращения</el-button>
    </div>
    <div class="exit">
      <el-button size="mini" plain @click="logOut()">Выйти</el-button>
    </div>

  </div>
</template>


<script>

  export default {
    computed: {
      account() {
        return this.$store.state.account;
      },
    },
    methods: {
      logOut () {
        this.$store.commit('LogOut')
      },
      GetListRequsetProcessed () {
        this.$store.commit('GetListRequsetProcessed')
      },
      GetListRequsetClosed () {
        this.$store.commit('GetListRequsetClosed')
      }
    }
  }

</script>


<style lang="scss">
  .controlbar {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		background-color: #ffffff;
    width: 100%;
    height: 50px;
    position: fixed;
    z-index: 999;
    border-bottom: 1px solid #eee;
  }
  .controlbar .account {
    line-height: 100%;
    padding: 0 20px;
    //border-right: 1px solid #ccc;
  }
  .controlbar .exit {
    padding: 0 20px;
  }

  .controlbar .account__first_name {
    font-family: "Segoe UI";
    font-size: 14pt;
    height: 100%;
    line-height: 100%;
  }

</style>
