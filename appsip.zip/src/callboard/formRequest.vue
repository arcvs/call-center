<template>
  <div class="form_request">

    <p class="header">Обращение</p>
    
    <el-form :model="ruleForm2" ref="ruleForm2">

        <el-row type="flex" :gutter="0" justify="space-between">

          <el-col :span="5">
            <div class="grid-content bg-purple">
              <el-form-item prop="name_person">
                <el-input size="small" placeholder="Имя" name="sss" v-model="ruleForm2.name_person" autocomplete="off"></el-input>       
              </el-form-item>
            </div>
          </el-col>


          <el-col :span="5">
            <div class="grid-content bg-purple">
              <el-form-item prop="number_phone">
                <el-input size="small" placeholder="Номер телефона" name="sss" v-model="ruleForm2.number_phone"></el-input>       
              </el-form-item>
            </div>
          </el-col>

          <el-col :span="6">
            <div class="grid-content bg-purple">
              <el-form-item prop="email">
                <el-input size="small" placeholder="Email" name="sss" v-model="ruleForm2.email"></el-input>       
              </el-form-item>
            </div>
          </el-col>
      
          <el-col :span="2"><div class="grid-content bg-purple-light" style="text-align: center"><strong>{{numberRequest}}</strong>  </div></el-col>
          
          <el-col :span="5">
            <div class="grid-content bg-purple" style="text-align: right">
              <el-button size="small" type="primary" v-on:click="createRequest">Создать обращение</el-button>
            </div>
          </el-col>

        </el-row>

        <el-form-item prop="description">
          <el-input
            class="marginTextArea"
            type="textarea"
            :autosize="{minRows: 2}"
            placeholder="Детализация обращение"
            v-model="ruleForm2.description">
          </el-input>
        </el-form-item>

        <el-row type="flex" :gutter="0" justify="space-between">
          <el-col :span="24">
            <div class="grid-content bg-purple" style="text-align: right">
              <el-button size="small" @click="resetForm('ruleForm2')">Очистить</el-button>
            </div>
          </el-col>
        </el-row>
        
    </el-form>
  </div>
</template>


<script>

  export default {
    data() {
      return {
        ruleForm2: {
          name_person: '',
          number_phone: '',
          email: '',
          description: ''
        },
        //input: this.$store.state.calleridnum
      }
    },
    computed: {
      active() {
        if (Object.keys(this.$store.state.activeQuestion).length != 0) {
          var groupQuestID = this.$store.state.activeQuestion.groupQuestID;
          var questID = this.$store.state.activeQuestion.questID;

          var nameDepartment = this.$store.state.questions[groupQuestID].questions[questID].nameDepartment
          var nameGroup = this.$store.state.questions[groupQuestID].questions[questID].nameGroup

          return nameGroup + ' - ' + nameDepartment;
        }
      },
      numberRequest () {
        if (this.$store.state.numberRequest) {
          this.$message({
            message: 'Обращение №' + this.$store.state.numberRequest + ' создано',
            type: 'success',
            center: true
          });
        }
        return this.$store.state.numberRequest
      },
      self_number_phone() {
        return this.$store.state.call.calleridnum;
      }
    },    
    mounted() {
    },
    methods: {
      createRequest () {

        //console.log(this.$store.state)

        var request = {} //this.$store.state.dataActiveQuestion
        
        if (Object.keys(this.$store.state.activeQuestion).length != 0) {
          var groupQuestID = this.$store.state.activeQuestion.groupQuestID;
          var questID = this.$store.state.activeQuestion.questID;

          request.question = this.$store.state.questions[groupQuestID].questions[questID].question
          request.directionToDepartmentId = this.$store.state.questions[groupQuestID].questions[questID].departmentId
          request.directionToGroupId = this.$store.state.questions[groupQuestID].questions[questID].groupId
        }

        request.descriptionRequest = this.ruleForm2.description
        request.numberPhone = this.ruleForm2.number_phone
        request.namePerson = this.ruleForm2.name_person
        request.email = this.ruleForm2.email

        this.$store.commit('CreateRequest', request)
      },
      resetForm (formName) {

        this.$store.commit('SetNumberRequest');
        this.$store.commit('setQuestion', {groupQuestID: null, questID:null})
        this.$refs[formName].resetFields();
      }
    }
  }

</script>


<style lang="scss">
  //.form_request {
  //}
  //.marginTextArea {
    //margin: 20px 0;
  //}
  .form_request .header {
    font-family: "Segoe UI Light";
    font-size: 21pt;
    color: #ccc;
    margin-top: 15px;
    margin-bottom: 15px;
  }
</style>
